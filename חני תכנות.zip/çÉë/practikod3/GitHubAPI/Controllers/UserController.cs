﻿using Microsoft.AspNetCore.Mvc;
using Octokit;
using service_GitHub.Service;

namespace GitHubAPI.Controllers
{
    [Route("api/[Controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IGitHubService _gitHubService;
        public UserController(IGitHubService gitHubService)
        {
            _gitHubService = gitHubService;
        }
       

        [HttpGet("/publicrepos")]
       public  async Task<ActionResult<List<Repository>>> GetPublicRepos(string? userRepo = null, string? lang = null, string? userName = null)
        {
         
            return await _gitHubService.SearchRepositories(userRepo,lang,userName);
        }
        [HttpGet("/Portfolio")]
        public async Task<ActionResult<Portfolio>> GetUserPortfolio()
        {
            return await _gitHubService.GetUserPortfolio();
        }
    }
}
