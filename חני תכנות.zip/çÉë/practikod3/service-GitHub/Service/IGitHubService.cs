﻿using Octokit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace service_GitHub.Service
{
    public interface IGitHubService
    {
        Task<int> GetUserPublicRepositories(string useName);
        Task<int> GetUserFollowersAsync(String userName);
        Task<List<Repository>> SearchRepositories(string? userRepo = null, string? lang = null, string? username = null);

        Task<IReadOnlyList<Repository>> GetUserRepos();
        Task<IReadOnlyList<Activity>> GetUserActivities();
        Task<Portfolio> GetUserPortfolio();
    }
}
