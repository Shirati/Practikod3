﻿using Microsoft.Extensions.Options;
using Octokit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace service_GitHub.Service
{
    public class GitHubService:IGitHubService
    {
        private readonly GitHubClient _clien;
        private readonly GitHubOption _gitHubOption;
        public GitHubService(IOptions<GitHubOption> options)
        {
            _clien = new GitHubClient(new ProductHeaderValue("my-github-app"));
            _gitHubOption = options.Value;
            _clien.Credentials = new Credentials(_gitHubOption.Token);

        }

        public async Task<IReadOnlyList<Activity>> GetUserActivities()
        {
            return await _clien.Activity.Events.GetAllUserPerformed(_gitHubOption.UserName);
        }

        public async Task<int> GetUserFollowersAsync(string userName)
        {
            var user = await _clien.User.Get(userName);
            return user.Followers;

        }

        public async Task<Portfolio> GetUserPortfolio()
        {
            var portfolio = new Portfolio();
            portfolio.UserName = _gitHubOption.UserName;    
            portfolio.Repositories = (await _clien.Repository.GetAllForCurrent()).ToList();
            return portfolio;

        }

        public async Task<int> GetUserPublicRepositories(String userName)
        {
            var user = await _clien.User.Get(userName);
            return user.PublicRepos;

        }

        public async Task<IReadOnlyList<Repository>> GetUserRepos()
        {
            return await _clien.Repository.GetAllForCurrent();
        }

        //public async Task<List<Repository>> SearchRepositories(string username, string userRepo, string lang)
        //{
        //    var request = new SearchRepositoriesRequest("repo-name") { Language = Language.Chuck };
        //    var result = await _clien.Search.SearchRepo(request);
        //    return result.Items.ToList();
        //}
        public async Task<List<Repository>> SearchRepositories(string? userRepo = null, string? lang = null, string? userName = null)
        {
            var search = "is:public ";

            if (!string.IsNullOrEmpty(userRepo))
                search += $"name:{userRepo} ";
            if (!string.IsNullOrEmpty(lang))
                search += $"language:{lang} ";
            if (!string.IsNullOrEmpty(userName))
                search += $"user:{userName} ";
            var request = new SearchRepositoriesRequest(search);
            var result = await _clien.Search.SearchRepo(request);
            return result.Items.ToList();
        }
    }
}

    

