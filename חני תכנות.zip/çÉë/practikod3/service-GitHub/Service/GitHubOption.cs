﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace service_GitHub.Service
{
    public class GitHubOption
    {
        public string UserName { get; set; }
        public string Token { get; set; }
    }
}
