﻿
using Microsoft.Extensions.Caching.Memory;
using Octokit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace service_GitHub.Service
{
    public class GitHubCached : IGitHubService
    { private readonly IGitHubService _gitHubService;
         private readonly IMemoryCache _memoryCache;
        private readonly string UserPrortfolioKey = "UserPortfolioKey";
        public GitHubCached(IGitHubService gitHubService,IMemoryCache memoryCache)
        {
            _gitHubService = gitHubService;
            _memoryCache = memoryCache;
         
        }

        public  async Task<IReadOnlyList<Activity>> GetUserActivities()
        {
           return await  _gitHubService.GetUserActivities();
        }

        public  async Task<int> GetUserFollowersAsync(string userName)
        {
           return await _gitHubService.GetUserFollowersAsync(userName);
        }

        public async Task<Portfolio> GetUserPortfolio()
        {
            if (_memoryCache.TryGetValue(UserPrortfolioKey, out Portfolio portfolio))
                return  portfolio;
            var option = new MemoryCacheEntryOptions()
                .SetAbsoluteExpiration(TimeSpan.FromSeconds(30))
                .SetSlidingExpiration(TimeSpan.FromSeconds(10));
          portfolio= await _gitHubService.GetUserPortfolio();
            _memoryCache.Set(UserPrortfolioKey, portfolio,option);
            return  portfolio;
        }

        public async Task<int> GetUserPublicRepositories(string useName)
        {
            return await _gitHubService.GetUserPublicRepositories(useName);
        }

        public async Task<IReadOnlyList<Repository>> GetUserRepos()
        {
           return await _gitHubService.GetUserRepos();
        }

        public async Task<List<Repository>> SearchRepositories(string? userRepo = null, string? lang = null, string? userName = null)
        {
            return await _gitHubService.SearchRepositories(userRepo,lang,userName); 
        }
    }
}
