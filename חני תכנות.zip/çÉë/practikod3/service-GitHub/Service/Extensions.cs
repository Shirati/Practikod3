﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace service_GitHub.Service
{
    public static class Extensions
    {
        public static void AddServerGitHub( this IServiceCollection services,Action<GitHubOption> configureOption)
        {
            services.Configure(configureOption);
            services.AddScoped<IGitHubService, GitHubService>();    
           // services.AddScoped<IGitHubService, GitHubCached>();

        }

    }
}
